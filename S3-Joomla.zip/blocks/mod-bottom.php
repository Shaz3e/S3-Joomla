<?php if($this->countModules('mod-bottom-1')): ?>
	<jdoc:include type="modules" name="mod-bottom-1" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-bottom-2')): ?>
	<jdoc:include type="modules" name="mod-bottom-2" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-bottom-3')): ?>
	<jdoc:include type="modules" name="mod-bottom-3" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-bottom-4')): ?>
	<jdoc:include type="modules" name="mod-bottom-4" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-bottom-5')): ?>
	<jdoc:include type="modules" name="mod-bottom-5" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-bottom-6')): ?>
	<jdoc:include type="modules" name="mod-bottom-6" style="shaz3e" />
<?php endif; ?>
