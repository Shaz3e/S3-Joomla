<?php if($this->countModules('mod-footer-1')): ?>
	<jdoc:include type="modules" name="mod-footer-1" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-footer-2')): ?>
	<jdoc:include type="modules" name="mod-footer-2" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-footer-3')): ?>
	<jdoc:include type="modules" name="mod-footer-3" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-footer-4')): ?>
	<jdoc:include type="modules" name="mod-footer-4" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-footer-5')): ?>
	<jdoc:include type="modules" name="mod-footer-5" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-footer-6')): ?>
	<jdoc:include type="modules" name="mod-footer-6" style="shaz3e" />
<?php endif; ?>
