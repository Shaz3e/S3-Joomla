<?php if($this->countModules('mod-bottom-footer-1')): ?>
	<jdoc:include type="modules" name="mod-bottom-footer-1" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-bottom-footer-2')): ?>
	<jdoc:include type="modules" name="mod-bottom-footer-2" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-bottom-footer-3')): ?>
	<jdoc:include type="modules" name="mod-bottom-footer-3" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-bottom-footer-4')): ?>
	<jdoc:include type="modules" name="mod-bottom-footer-4" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-bottom-footer-5')): ?>
	<jdoc:include type="modules" name="mod-bottom-footer-5" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-bottom-footer-6')): ?>
	<jdoc:include type="modules" name="mod-bottom-footer-6" style="shaz3e" />
<?php endif; ?>
