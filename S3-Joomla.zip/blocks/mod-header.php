<?php if($this->countModules('mod-header-1')): ?>
	<jdoc:include type="modules" name="mod-header-1" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-header-2')): ?>
	<jdoc:include type="modules" name="mod-header-2" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-header-3')): ?>
	<jdoc:include type="modules" name="mod-header-3" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-header-4')): ?>
	<jdoc:include type="modules" name="mod-header-4" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-header-5')): ?>
	<jdoc:include type="modules" name="mod-header-5" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-header-6')): ?>
	<jdoc:include type="modules" name="mod-header-6" style="shaz3e" />
<?php endif; ?>