<?php if($this->countModules('mod-menu-1')): ?>
	<jdoc:include type="modules" name="mod-menu-1" style="s3_none" />
<?php endif; ?>
<?php if($this->countModules('mod-menu-2')): ?>
	<jdoc:include type="modules" name="mod-menu-2" style="s3_none" />
<?php endif; ?>
<?php if($this->countModules('mod-menu-3')): ?>
	<jdoc:include type="modules" name="mod-menu-3" style="s3_none" />
<?php endif; ?>
<?php if($this->countModules('mod-menu-4')): ?>
	<jdoc:include type="modules" name="mod-menu-4" style="s3_none" />
<?php endif; ?>
<?php if($this->countModules('mod-menu-5')): ?>
	<jdoc:include type="modules" name="mod-menu-5" style="s3_none" />
<?php endif; ?>
<?php if($this->countModules('mod-menu-6')): ?>
	<jdoc:include type="modules" name="mod-menu-6" style="s3_none" />
<?php endif; ?>