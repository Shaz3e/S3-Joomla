<?php if($this->countModules('mod-top-1')): ?>
	<jdoc:include type="modules" name="mod-top-1" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-top-2')): ?>
	<jdoc:include type="modules" name="mod-top-2" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-top-3')): ?>
	<jdoc:include type="modules" name="mod-top-3" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-top-4')): ?>
	<jdoc:include type="modules" name="mod-top-4" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-top-5')): ?>
	<jdoc:include type="modules" name="mod-top-5" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-top-6')): ?>
	<jdoc:include type="modules" name="mod-top-6" style="shaz3e" />
<?php endif; ?>
