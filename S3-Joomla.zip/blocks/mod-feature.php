<?php if($this->countModules('mod-feature-1')): ?>
	<jdoc:include type="modules" name="mod-feature-1" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-feature-2')): ?>
	<jdoc:include type="modules" name="mod-feature-2" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-feature-3')): ?>
	<jdoc:include type="modules" name="mod-feature-3" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-feature-4')): ?>
	<jdoc:include type="modules" name="mod-feature-4" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-feature-5')): ?>
	<jdoc:include type="modules" name="mod-feature-5" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-feature-6')): ?>
	<jdoc:include type="modules" name="mod-feature-6" style="shaz3e" />
<?php endif; ?>
