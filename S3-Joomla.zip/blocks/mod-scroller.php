<?php if($this->countModules('mod-scroller-1')): ?>
	<jdoc:include type="modules" name="mod-scroller-1" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-scroller-2')): ?>
	<jdoc:include type="modules" name="mod-scroller-2" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-scroller-3')): ?>
	<jdoc:include type="modules" name="mod-scroller-3" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-scroller-4')): ?>
	<jdoc:include type="modules" name="mod-scroller-4" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-scroller-5')): ?>
	<jdoc:include type="modules" name="mod-scroller-5" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-scroller-6')): ?>
	<jdoc:include type="modules" name="mod-scroller-6" style="shaz3e" />
<?php endif; ?>
