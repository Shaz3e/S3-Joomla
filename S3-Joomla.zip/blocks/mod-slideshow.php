<?php if($this->countModules('mod-slideshow-1')): ?>
	<jdoc:include type="modules" name="mod-slideshow-1" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-slideshow-2')): ?>
	<jdoc:include type="modules" name="mod-slideshow-2" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-slideshow-3')): ?>
	<jdoc:include type="modules" name="mod-slideshow-3" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-slideshow-4')): ?>
	<jdoc:include type="modules" name="mod-slideshow-4" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-slideshow-5')): ?>
	<jdoc:include type="modules" name="mod-slideshow-5" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-slideshow-6')): ?>
	<jdoc:include type="modules" name="mod-slideshow-6" style="shaz3e" />
<?php endif; ?>
