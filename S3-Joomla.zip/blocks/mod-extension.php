<?php if($this->countModules('mod-extension-1')): ?>
	<jdoc:include type="modules" name="mod-extension-1" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-extension-2')): ?>
	<jdoc:include type="modules" name="mod-extension-2" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-extension-3')): ?>
	<jdoc:include type="modules" name="mod-extension-3" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-extension-4')): ?>
	<jdoc:include type="modules" name="mod-extension-4" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-extension-5')): ?>
	<jdoc:include type="modules" name="mod-extension-5" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-extension-6')): ?>
	<jdoc:include type="modules" name="mod-extension-6" style="shaz3e" />
<?php endif; ?>
