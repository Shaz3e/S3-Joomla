<?php if($this->countModules('mod-breadcrumb-1')): ?>
	<jdoc:include type="modules" name="mod-breadcrumb-1" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-breadcrumb-2')): ?>
	<jdoc:include type="modules" name="mod-breadcrumb-2" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-breadcrumb-3')): ?>
	<jdoc:include type="modules" name="mod-breadcrumb-3" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-breadcrumb-4')): ?>
	<jdoc:include type="modules" name="mod-breadcrumb-4" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-breadcrumb-5')): ?>
	<jdoc:include type="modules" name="mod-breadcrumb-5" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-breadcrumb-6')): ?>
	<jdoc:include type="modules" name="mod-breadcrumb-6" style="shaz3e" />
<?php endif; ?>
