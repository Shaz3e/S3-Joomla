<?php if($this->countModules('mod-showcase-1')): ?>
	<jdoc:include type="modules" name="mod-showcase-1" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-showcase-2')): ?>
	<jdoc:include type="modules" name="mod-showcase-2" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-showcase-3')): ?>
	<jdoc:include type="modules" name="mod-showcase-3" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-showcase-4')): ?>
	<jdoc:include type="modules" name="mod-showcase-4" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-showcase-5')): ?>
	<jdoc:include type="modules" name="mod-showcase-5" style="shaz3e" />
<?php endif; ?>
<?php if($this->countModules('mod-showcase-6')): ?>
	<jdoc:include type="modules" name="mod-showcase-6" style="shaz3e" />
<?php endif; ?>
